var TelegramBot = require('node-telegram-bot-api');
var Bluebird = require('bluebird');
const TOKEN = '356048522:AAE6msHOwWC9asbK7fCPCWd9p7Y5pWyYl1A';

var options = {
  polling: {
    interval: 1000,
    params: 20
  }
}

var bot = new TelegramBot(TOKEN, options);

var savedText = [];
var counter = 0;
var commands = [/^\/store\s(.+)/i, /^\/repeat\s(.+)/i, /^\/list/i];

var commandCheck = function(input)
{
  for(var x = 0 ; x<commands.length; x++)
  {
    if(input === commands[x])
    {
      return true;
    }
  }
  return false;
};

bot.onText(/^\/echo\s(.+)/i, function (msg, match)
{
  var reply = match[1];
  var replyChatId = msg.chat.id;
  bot.sendMessage(replyChatId, reply);
  console.log(reply)
  console.log(counter)
  console.log(match);
  console.log(msg);
});
bot.onText(/^\/store\s(.+)/i, function (msg, match)
{
  var reply = match[1];
  var replyChatId = msg.chat.id;
  bot.sendMessage(replyChatId, "message stored");
  savedText[counter] = reply;
  counter++;
});

bot.onText(/^\/repeat\s(.+)/i, function (msg, match)
{
  var repeatNum = match[1];
  console.log(repeatNum);
  var replyChatId = msg.chat.id;
  if(repeatNum > counter || repeatNum<=0)
  {
    bot.sendMessage(replyChatId, "Invalid input");
  }
  else
  {
    var reply = savedText[repeatNum-1];
    bot.sendMessage(replyChatId, reply);
  }
});

bot.onText(/^\/list/i, function(msg, match)
{
  var replyChatId = msg.chat.id;
  var output= "";
  for(var x = 0; x<counter;x++)
  {
    var y = x+1;
    output += y+ ": " + savedText[x]+"\n";
  }
  bot.sendMessage(replyChatId, output);
});

bot.on('message', function(msg, match)
{
  console.log(msg);
  if(commandCheck(msg.text) === false)
  {
    bot.sendMessage(msg.chat.id, "invalid input");
  }
})
